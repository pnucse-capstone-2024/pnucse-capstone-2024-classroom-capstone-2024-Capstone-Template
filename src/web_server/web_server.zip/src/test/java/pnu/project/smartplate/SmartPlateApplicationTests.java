package pnu.project.smartplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartPlateApplicationTests {

    @Test
    void contextLoads() {
    }

}
